<?php

namespace Pterodactyl\Http\Requests\Api\Application\Nests;

class GetNestRequest extends GetNestsRequest
{
}
