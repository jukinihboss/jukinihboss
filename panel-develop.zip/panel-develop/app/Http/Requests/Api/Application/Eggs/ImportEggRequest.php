<?php

namespace Pterodactyl\Http\Requests\Api\Application\Eggs;

use Pterodactyl\Http\Requests\Api\Application\ApplicationApiRequest;

class ImportEggRequest extends ApplicationApiRequest
{
}
