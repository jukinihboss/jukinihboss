<?php

namespace Pterodactyl\Http\Requests\Api\Application\Mounts;

class GetMountRequest extends GetMountsRequest
{
}
