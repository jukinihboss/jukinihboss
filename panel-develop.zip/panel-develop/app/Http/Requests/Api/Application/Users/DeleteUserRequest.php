<?php

namespace Pterodactyl\Http\Requests\Api\Application\Users;

use Pterodactyl\Http\Requests\Api\Application\ApplicationApiRequest;

class DeleteUserRequest extends ApplicationApiRequest
{
}
